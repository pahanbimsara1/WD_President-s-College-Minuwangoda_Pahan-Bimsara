
(function(){
  const DPR = () => Math.max(1, window.devicePixelRatio || 1);


  function startLoader(){
    const loader = document.getElementById('loader');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    const loaderDots = document.getElementById('loaderDots');


    const antDot = document.getElementById('antDot');
    const eyeL = document.getElementById('eyeL');
    const eyeR = document.getElementById('eyeR');
    const armL = document.getElementById('armLeft');
    const armR = document.getElementById('armRight');


    function setup() {
      const dpr = DPR();
      const W = 420, H = 36;
      loaderDots.width = W * dpr; loaderDots.height = H * dpr;
      loaderDots.style.width = W + 'px'; loaderDots.style.height = H + 'px';
      const ctx = loaderDots.getContext('2d');
      ctx.setTransform(dpr,0,0,dpr,0,0);
      return { ctx, W, H };
    }
    const cfg = setup();
    const ctx = cfg.ctx;
    const DOTS = 34;
    const dots = Array.from({length:DOTS}, (_, i) => ({
      x: 10 + i*((cfg.W - 20)/(DOTS-1)),
      baseY: cfg.H/2 + Math.sin(i*0.55)*4,
      r: 2.8 + (i%3)*0.5,
      phase: Math.random()*Math.PI*2
    }));

    function drawDots(pct){
      ctx.clearRect(0,0,cfg.W,cfg.H);
      const t = performance.now()*0.002;
      for(let i=0;i<DOTS;i++){
        const d = dots[i];
        const y = d.baseY + Math.sin(d.phase + t + i*0.12)*2.2;
        const lit = i < Math.round((pct/100)*DOTS);
        ctx.beginPath(); ctx.arc(d.x, y, d.r, 0, Math.PI*2);
        ctx.fillStyle = lit ? 'rgba(0,212,255,1)' : 'rgba(255,255,255,0.06)';
        ctx.fill();
        if(lit){
          ctx.beginPath(); ctx.arc(d.x, y, d.r+3.6, 0, Math.PI*2);
          ctx.fillStyle = 'rgba(0,212,255,0.06)'; ctx.fill();
        }
      }
    }


    (function run(){
      const DURATION = 5000;
      const start = performance.now();
      let finished = false;

      function step(now){
        const elapsed = now - start;
        const pct = Math.min(100, (elapsed / DURATION) * 100);
        const p = Math.floor(pct);
        progressBar.style.width = p + '%';
        progressBar.setAttribute('aria-valuenow', String(p));
        progressText.textContent = p + '%';
        drawDots(pct);

 
        const t = performance.now()*0.002;
        if (antDot) antDot.setAttribute('transform', `scale(${1 + Math.sin(t*6)*0.035})`);
        if (eyeL && eyeR) {
          const blink = (Math.abs(Math.sin(t*2.2)) > 0.95); 
          eyeL.setAttribute('fill-opacity', blink ? '0.18' : '1');
          eyeR.setAttribute('fill-opacity', blink ? '0.18' : '1');
        }
        if (armL) armL.setAttribute('transform', `rotate(${Math.sin(t*3.2)*8}, 0, 0) translate(0, ${Math.sin(t*2.1)*1.6})`);
        if (armR) armR.setAttribute('transform', `rotate(${Math.cos(t*3.2)*8}, 0, 0) translate(0, ${Math.cos(t*2.1)*1.6})`);

        if (elapsed < DURATION) requestAnimationFrame(step);
        else if (!finished){ finished = true; finish(); }
      }
      requestAnimationFrame(step);

   
      setTimeout(()=>{ if(!finished){ finished=true; progressBar.style.width='100%'; progressText.textContent='100%'; drawDots(100); finish(); } }, DURATION+500);
    })();

    function finish(){
    
      document.querySelectorAll('.glitch').forEach(el => el.classList.add('glitching','jitter'));
      setTimeout(()=>{
        const main = document.getElementById('main');
        if(main) main.classList.remove('hidden');
        loader.style.transition = 'opacity .45s, transform .45s';
        loader.style.opacity = '0';
        loader.style.transform = 'translateY(-8px) scale(.995)';
      }, 300);

      setTimeout(()=>{
        try{ loader.remove(); } catch(e){ loader.style.display='none'; }
        setTimeout(()=>document.querySelectorAll('.glitch').forEach(el=>el.classList.remove('glitching','jitter')),700);
        const main = document.getElementById('main'); if(main) main.focus({preventScroll:true});
      }, 1000);
    }


    window.addEventListener('resize', ()=>{
      if(loaderDots) {
        const dpr = DPR(); const W=420,H=36;
        loaderDots.width = W * dpr; loaderDots.height = H * dpr;
        loaderDots.style.width = W + 'px'; loaderDots.style.height = H + 'px';
        const c = loaderDots.getContext('2d'); c.setTransform(dpr,0,0,dpr,0,0);
      }
    });
  }


  function startBg(){
    const canvas = document.getElementById('bgCanvas'); if(!canvas) return;
    const ctx = canvas.getContext('2d', {alpha:true});
    let W=innerWidth, H=innerHeight, nodes=[];

    function resize(){
      const dpr = DPR(); W = innerWidth; H = innerHeight;
      canvas.width = Math.floor(W * dpr); canvas.height = Math.floor(H * dpr);
      canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
      ctx.setTransform(dpr,0,0,dpr,0,0);
      const area = W * H; const count = Math.min(420, Math.max(140, Math.round(area / 28000)));
      nodes = [];
      for(let i=0;i<count;i++) nodes.push({ x:Math.random()*W, y:Math.random()*H, vx:(Math.random()-0.5)*0.12, vy:(Math.random()-0.5)*0.12, r:1.6+Math.random()*1.4 });
    }
    addEventListener('resize', resize); resize();

    function kNearest(i,k,maxd){
      const a = nodes[i]; const arr=[];
      for(let j=0;j<nodes.length;j++){ if(i===j) continue; const b = nodes[j]; const dx=a.x-b.x, dy=a.y-b.y; arr.push({idx:j,d2:dx*dx+dy*dy}); }
      arr.sort((p,q)=>p.d2-q.d2);
      const res=[]; for(let t=0;t<Math.min(k,arr.length);t++) if(arr[t].d2 <= maxd*maxd) res.push(arr[t].idx);
      return res;
    }

    let mouse = {x:W/2,y:H/2,active:false};
    window.addEventListener('pointermove', e => { mouse.x = e.clientX; mouse.y = e.clientY; mouse.active = true; });

    function step(){
      ctx.clearRect(0,0,W,H);
      for(const n of nodes){
        n.x += n.vx + Math.sin((n.y + performance.now()*0.00012)*0.001)*0.02;
        n.y += n.vy + Math.cos((n.x + performance.now()*0.00014)*0.001)*0.02;
        if(mouse.active){
          const dx = n.x - mouse.x, dy = n.y - mouse.y, d = Math.sqrt(dx*dx+dy*dy);
          if(d < 140){ const f = (140-d)/140; n.vx += (dx/(d+0.01))*0.03*f; n.vy += (dy/(d+0.01))*0.03*f; }
        }
        if(n.x < -20) n.x = W + 20; if(n.x > W + 20) n.x = -20;
        if(n.y < -20) n.y = H + 20; if(n.y > H + 20) n.y = -20;
      }

  
      ctx.lineWidth = 1; ctx.setLineDash([3,6]);
      const K=4, MAXD=140;
      for(let i=0;i<nodes.length;i++){
        const a = nodes[i];
        const near = kNearest(i,K,MAXD);
        for(const j of near){
          const b = nodes[j]; const dx=a.x-b.x, dy=a.y-b.y; const dist = Math.sqrt(dx*dx+dy*dy);
          const alpha = 0.28*(1 - (dist/MAXD));
          if(alpha > 0.02){ ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.strokeStyle = `rgba(123,97,255,${alpha.toFixed(3)})`; ctx.stroke(); }
        }
      }
      ctx.setLineDash([]);

 
      for(const n of nodes){ ctx.beginPath(); ctx.arc(n.x,n.y,n.r,0,Math.PI*2); ctx.fillStyle='rgba(0,212,255,0.95)'; ctx.fill(); }

      requestAnimationFrame(step);
    }
    step();
  }


  function startInteractive(){
    const canvas = document.getElementById('interactiveCanvas'); if(!canvas) return;
    const ctx = canvas.getContext('2d');
    let w=800,h=320,nodes=[];

    function resize(){
      const dpr = DPR(); const rect = canvas.getBoundingClientRect();
      w = Math.max(300, rect.width); h = Math.max(180, rect.height);
      canvas.width = Math.floor(w * dpr); canvas.height = Math.floor(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      ctx.setTransform(dpr,0,0,dpr,0,0); init();
    }
    function init(){ nodes = []; const count = Math.max(12, Math.round(w/70)); for(let i=0;i<count;i++) nodes.push({ x:Math.random()*w, y:Math.random()*h, r:2+Math.random()*3, vx:(Math.random()-0.5)*0.6, vy:(Math.random()-0.5)*0.6 }); }
    const ro = new ResizeObserver(resize); ro.observe(canvas); resize();

    let mouse = {x:-9999,y:-9999,active:false};
    canvas.addEventListener('pointermove', e => { const r = canvas.getBoundingClientRect(); mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; mouse.active = true; });
    canvas.addEventListener('pointerleave', ()=>{ mouse.x=-9999; mouse.y=-9999; mouse.active=false; });

    function draw(){
      ctx.clearRect(0,0,w,h);
      for(let i=0;i<nodes.length;i++){
        const n = nodes[i]; n.x += n.vx; n.y += n.vy;
        if(n.x < -10) n.x = w + 10; if(n.x > w + 10) n.x = -10;
        if(n.y < -10) n.y = h + 10; if(n.y > h + 10) n.y = -10;

        if(mouse.active){
          const dx = n.x - mouse.x, dy = n.y - mouse.y, d = Math.sqrt(dx*dx + dy*dy);
          if(d < 90 && d > 0){ const f = (90 - d)/90; n.x += (dx/d)*f*2; n.y += (dy/d)*f*2; }
        }
        ctx.beginPath(); ctx.arc(n.x, n.y, n.r, 0, Math.PI*2); ctx.fillStyle = 'rgba(123,97,255,0.95)'; ctx.fill();
      }


      for(let i=0;i<nodes.length;i++){
        const a = nodes[i]; const arr=[];
        for(let j=0;j<nodes.length;j++){ if(i===j) continue; const b=nodes[j]; const dx=a.x-b.x, dy=a.y-b.y; arr.push({idx:j,d2:dx*dx+dy*dy}); }
        arr.sort((p,q)=>p.d2-q.d2);
        for(let t=0;t<Math.min(3,arr.length);t++){
          const b = nodes[arr[t].idx]; const d = Math.sqrt(arr[t].d2); const alpha = 0.16 * (1 - Math.min(1, d/140));
          if(alpha > 0.02){ ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.strokeStyle = `rgba(0,212,255,${alpha.toFixed(3)})`; ctx.lineWidth=0.8; ctx.stroke(); }
        }
      }

      requestAnimationFrame(draw);
    }
    draw();
  }

 
  function menuSetup(){
    const dotsBtn = document.getElementById('dotsBtn');
    const hamburger = document.getElementById('hamburger');
    const overlay = document.getElementById('menuOverlay');
    const closeBtn = document.getElementById('menuClose');

    function toggle(open){
      overlay.classList.toggle('open', open);
      overlay.style.display = open ? 'flex' : 'none';
      if(hamburger) hamburger.classList.toggle('open', open);
      if(dotsBtn) dotsBtn.setAttribute('aria-expanded', String(open));
      if(hamburger) hamburger.setAttribute('aria-expanded', String(open));
    }

    if(dotsBtn) dotsBtn.addEventListener('click', ()=> toggle(!overlay.classList.contains('open')));
    if(hamburger) hamburger.addEventListener('click', ()=> toggle(!overlay.classList.contains('open')));
    if(closeBtn) closeBtn.addEventListener('click', ()=> toggle(false));
    overlay.addEventListener('click', (e)=>{ if(e.target === overlay) toggle(false); });
  }


  function revealSetup(){
    const items = Array.from(document.querySelectorAll('.reveal'));
    if('IntersectionObserver' in window){
      const obs = new IntersectionObserver((entries, o) => { entries.forEach(en => { if(en.isIntersecting){ en.target.classList.add('show'); o.unobserve(en.target); } }); }, { threshold: 0.18 });
      items.forEach(it => obs.observe(it));
    } else items.forEach(it => it.classList.add('show'));
  }

  function contactSetup(){
    const form = document.getElementById('contactForm');
    const year = document.getElementById('year');
    if(year) year.textContent = new Date().getFullYear();
    if(!form) return;
    form.addEventListener('submit', (e)=>{ e.preventDefault(); const fd=new FormData(form);
      if(!fd.get('name')||!fd.get('email')||!fd.get('message')){ alert('Please fill all fields'); return; }
      alert('Message sent (demo). Thank you!');
      form.reset();
    });
  }

  function chatbotFix(){
    const bot = document.getElementById('chatbot'); if(!bot) return; bot.addEventListener('dragstart', e => e.preventDefault());
  }


  document.addEventListener('DOMContentLoaded', ()=>{
    startLoader();
    startBg();
    startInteractive();
    menuSetup();
    revealSetup();
    contactSetup();
    chatbotFix();
  });

})();
